import java.time.LocalDate;
import java.util.List;
import java.math.BigDecimal;

public class Matricula {
    private int id;
    private LocalDate dataMatricula;
    private int numeroPrestacoes;
    private Aluno aluno;
    private Turma turma;
    private List<Resultado> resultados;

public Matricula() {
	
}
public Matricula(int id,LocalDate dataMatricula,int numeroPrestacoes,Aluno aluno,Turma turma,List<Resultado> resultados) {
	 this.id = id;
		this.dataMatricula=dataMatricula;
		this.numeroPrestacoes=numeroPrestacoes;
		this.aluno=aluno;
		this.turma=turma;
		this.resultados=resultados;
}
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public LocalDate getDataMatricula() {
		return dataMatricula;
	}

	public void setDataMatricula(LocalDate dataMatricula) {
		this.dataMatricula = dataMatricula;
	}

	public int getNumeroPrestacoes() {
		return numeroPrestacoes;
	}

	public void setNumeroPrestacoes(int numeroPrestacoes) {
		this.numeroPrestacoes = numeroPrestacoes;
	}

	public Aluno getAluno() {
		return aluno;
	}

	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}

	public Turma getTurma() {
		return turma;
	}

	public void setTurma(Turma turma) {
		this.turma = turma;
	}

	public List<Resultado> getResultados() {
		return resultados;
	}

	public void setResultados(List<Resultado> resultados) {
		this.resultados = resultados;
	}

	public BigDecimal getNotaFinal() {
        if (resultados == null || resultados.isEmpty()) return BigDecimal.ZERO;

        return resultados.stream()
            .map(Resultado::getNota)
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public boolean isAprovado() {
    	 return getNotaFinal().compareTo(new BigDecimal("70")) >= 0;
    }
}
