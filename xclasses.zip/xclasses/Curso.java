import java.math.BigDecimal;
import java.util.List;

public class Curso {
	private int id;
	private String nome;
	private int cargaHoraria;
	private BigDecimal valor;
	private List<Turma> turmas;

	public Curso() {

	}

	public Curso(int id, String nome, int cargaHoraria, BigDecimal valor, List<Turma> turmas) {
		this.id = id;
		this.nome = nome;
		this.cargaHoraria = cargaHoraria;
		this.valor = valor;
		this.turmas = turmas;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCargaHoraria() {
		return cargaHoraria;
	}

	public void setCargaHoraria(int cargaHoraria) {
		this.cargaHoraria = cargaHoraria;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public List<Turma> getTurmas() {
		return turmas;
	}

	public void setTurmas(List<Turma> turmas) {
		this.turmas = turmas;
	}

}
