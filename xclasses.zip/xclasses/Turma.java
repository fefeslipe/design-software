import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public class Turma {
	private int id;
	private int numero;
	private LocalDate dataInicio;
	private int numeroVagas;
	private Curso curso;
	private List<Matricula> matriculas;
	private List<Avaliacao> avaliacoes;
	private boolean finalizada;

	public Turma() {

	}

	public Turma(int id, int numero, LocalDate dataInicio, int numeroVagas, Curso curso, List<Matricula> matriculas,
			List<Avaliacao> avaliacoes, boolean finalizada) {
		this.id = id;
		this.numero=numero;
		this.dataInicio=dataInicio;
		this.numeroVagas=numeroVagas;
		this.curso=curso;
		this.matriculas=matriculas;
		this.avaliacoes=avaliacoes;
		this.finalizada=finalizada;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public LocalDate getDataInicio() {
		return dataInicio;
	}

	public void setDataInicio(LocalDate dataInicio) {
		this.dataInicio = dataInicio;
	}

	public int getNumeroVagas() {
		return numeroVagas;
	}

	public void setNumeroVagas(int numeroVagas) {
		this.numeroVagas = numeroVagas;
	}

	public Curso getCurso() {
		return curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public List<Matricula> getMatriculas() {
		return matriculas;
	}

	public void setMatriculas(List<Matricula> matriculas) {
		this.matriculas = matriculas;
	}

	public List<Avaliacao> getAvaliacoes() {
		return avaliacoes;
	}

	public void setAvaliacoes(List<Avaliacao> avaliacoes) {
		this.avaliacoes = avaliacoes;
	}

	public boolean isFinalizada() {
		return finalizada;
	}

	public void setFinalizada(boolean finalizada) {
		this.finalizada = finalizada;
	}

	public double calcularPorcentagemAprovacao() {
		if (matriculas == null || matriculas.isEmpty())
			return 0.0;

		long total = matriculas.size();
		long aprovados = matriculas.stream().filter(Matricula::isAprovado).count();

		return (aprovados * 100.0) / total;
	}

	public List<Aluno> getMelhoresAlunos() {
		BigDecimal maiorNota = matriculas.stream().map(Matricula::getNotaFinal).max(BigDecimal::compareTo)
				.orElse(BigDecimal.ZERO);

		return matriculas.stream().filter(m -> m.getNotaFinal().compareTo(maiorNota) == 0).map(Matricula::getAluno)
				.toList();
	}

}
