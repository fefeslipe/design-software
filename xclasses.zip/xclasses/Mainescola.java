import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Mainescola {

    public static void main(String[] args) {
     
        Curso curso = new Curso();
        curso.setId(1);
        curso.setNome("Java Avançado");
        curso.setCargaHoraria(120);
        curso.setValor(new BigDecimal("2000"));

     
        Turma turma = new Turma();
        turma.setId(1);
        turma.setNumero(101);
        turma.setDataInicio(LocalDate.of(2023, 8, 1));
        turma.setNumeroVagas(30);
        turma.setCurso(curso);

      
        Aluno aluno1 = new Aluno();
        aluno1.setId(1);
        aluno1.setNome("Matheus");
        aluno1.setCpf("123.456.789-00");	
        aluno1.setDataNascimento(LocalDate.of(1995, 5, 20));

        Aluno aluno2 = new Aluno();
        aluno2.setId(2);
        aluno2.setNome("Gabriel");
        aluno2.setCpf("987.654.321-00");
        aluno2.setDataNascimento(LocalDate.of(1997, 3, 15));
        
        Aluno aluno3 = new Aluno();
        aluno3.setId(3);
        aluno3.setNome("Victor");
        aluno3.setCpf("987.654.321-00");
        aluno3.setDataNascimento(LocalDate.of(1997, 3, 15));


      
        Matricula matricula1 = new Matricula();
        matricula1.setId(1);
        matricula1.setDataMatricula(LocalDate.of(2023, 7, 15));
        matricula1.setNumeroPrestacoes(10);
        matricula1.setAluno(aluno1);
        matricula1.setTurma(turma);

        Matricula matricula2 = new Matricula();
        matricula2.setId(2);
        matricula2.setDataMatricula(LocalDate.of(2023, 7, 20));
        matricula2.setNumeroPrestacoes(10);
        matricula2.setAluno(aluno2);
        matricula2.setTurma(turma);
        
        Matricula matricula3 = new Matricula();
        matricula3.setId(3);
        matricula3.setDataMatricula(LocalDate.of(2023, 7, 20));
        matricula3.setNumeroPrestacoes(10);
        matricula3.setAluno(aluno3);
        matricula3.setTurma(turma);

      
        List<Matricula> matriculasAluno1 = new ArrayList<>();
        matriculasAluno1.add(matricula1);
        aluno1.setMatriculas(matriculasAluno1);

        List<Matricula> matriculasAluno2 = new ArrayList<>();
        matriculasAluno2.add(matricula2);
        aluno2.setMatriculas(matriculasAluno2);
        

        List<Matricula> matriculasAluno3 = new ArrayList<>();
        matriculasAluno3.add(matricula3);
        aluno2.setMatriculas(matriculasAluno3);

      
        List<Matricula> matriculasTurma = new ArrayList<>();
        matriculasTurma.add(matricula1);
        matriculasTurma.add(matricula2);
        matriculasTurma.add(matricula3);
        turma.setMatriculas(matriculasTurma);

 
        Avaliacao avaliacao1 = new Avaliacao();
        avaliacao1.setId(1);
        avaliacao1.setDescricao("Avaliação 1");
        avaliacao1.setData(LocalDate.of(2023, 9, 1));
        avaliacao1.setNotaMaxima(new BigDecimal("100"));
        avaliacao1.setTurma(turma);

        Avaliacao avaliacao2 = new Avaliacao();
        avaliacao2.setId(2);
        avaliacao2.setDescricao("Avaliação 2");
        avaliacao2.setData(LocalDate.of(2023, 9, 15));
        avaliacao2.setNotaMaxima(new BigDecimal("100"));
        avaliacao2.setTurma(turma);
        
        Avaliacao avaliacao3 = new Avaliacao();
        avaliacao3.setId(3);
        avaliacao3.setDescricao("Avaliação 3");
        avaliacao3.setData(LocalDate.of(2023, 10, 20));
        avaliacao3.setNotaMaxima(new BigDecimal("100"));
        avaliacao3.setTurma(turma);

     
        List<Avaliacao> avaliacoes = new ArrayList<>();
        avaliacoes.add(avaliacao1);
        avaliacoes.add(avaliacao2);
        avaliacoes.add(avaliacao3);
        turma.setAvaliacoes(avaliacoes);

      
        Resultado resultado1 = new Resultado();
        resultado1.setId(1);
        resultado1.setNota(new BigDecimal("20"));
        resultado1.setMatricula(matricula1);
        resultado1.setAvaliacao(avaliacao1);

        Resultado resultado2 = new Resultado();
        resultado2.setId(2);
        resultado2.setNota(new BigDecimal("30"));
        resultado2.setMatricula(matricula1);
        resultado2.setAvaliacao(avaliacao2);

        Resultado resultado3 = new Resultado();
        resultado3.setId(3);
        resultado3.setNota(new BigDecimal("10"));
        resultado3.setMatricula(matricula2);
        resultado3.setAvaliacao(avaliacao1);

        Resultado resultado4 = new Resultado();
        resultado4.setId(4);
        resultado4.setNota(new BigDecimal("60"));
        resultado4.setMatricula(matricula2);
        resultado4.setAvaliacao(avaliacao2);

     
        List<Resultado> resultadosAluno1 = new ArrayList<>();
        resultadosAluno1.add(resultado1);
        resultadosAluno1.add(resultado2);
        matricula1.setResultados(resultadosAluno1);

        List<Resultado> resultadosAluno2 = new ArrayList<>();
        resultadosAluno2.add(resultado3);
        resultadosAluno2.add(resultado4);
        matricula2.setResultados(resultadosAluno2);

        List<Resultado> resultadosAluno3 = new ArrayList<>();
        resultadosAluno3.add(resultado1);
        resultadosAluno3.add(resultado4);
        matricula3.setResultados(resultadosAluno3);

        
        System.out.println("Nota final do Matheus: " + matricula1.getNotaFinal());
        System.out.println("Nota final da Gabriel: " + matricula2.getNotaFinal());
        System.out.println("Nota final da Victor: " + matricula3.getNotaFinal());

      
        System.out.println("Matheus foi aprovado? " + matricula1.isAprovado());
        System.out.println("Gabriel foi aprovada? " + matricula2.isAprovado());
        System.out.println("Victor foi aprovada? " + matricula3.isAprovado());
       
    
        System.out.println("Porcentagem de aprovação da turma: " + turma.calcularPorcentagemAprovacao() + "%");

      
        System.out.println("Melhores alunos da turma: ");
        turma.getMelhoresAlunos().forEach(a -> System.out.println(a.getNome()));
    }
}
