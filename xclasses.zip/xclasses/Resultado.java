import java.math.BigDecimal;

public class Resultado {
	private int id;
	private BigDecimal nota;
	private Matricula matricula;
	private Avaliacao avaliacao;

	public Resultado() {

	}

	public Resultado(int id, BigDecimal nota, Matricula matricula, Avaliacao avaliacao) {
		this.id = id;
		this.nota = nota;
		this.matricula = matricula;
		this.avaliacao = avaliacao;

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public BigDecimal getNota() {
		return nota;
	}

	public void setNota(BigDecimal nota) {
		this.nota = nota;
	}

	public Matricula getMatricula() {
		return matricula;
	}

	public void setMatricula(Matricula matricula) {
		this.matricula = matricula;
	}

	public Avaliacao getAvaliacao() {
		return avaliacao;
	}

	public void setAvaliacao(Avaliacao avaliacao) {
		this.avaliacao = avaliacao;
	}

}
