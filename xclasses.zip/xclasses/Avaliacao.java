import java.time.LocalDate;
import java.math.BigDecimal;
import java.util.List;

public class Avaliacao {
    private int id;
    private String descricao;
    private LocalDate data;
    private BigDecimal notaMaxima;
    private Turma turma;
    private List<Resultado> resultados;
    public Avaliacao(){
    	
    }
   public Avaliacao(int id, String descricao, LocalDate data,BigDecimal notaMaxima,Turma turma,List<Resultado> resultados){
    	this.id=id;
    	this.descricao=descricao;
    	this.data=data;
    	this.notaMaxima=notaMaxima;
    	this.turma=turma;
    	this.resultados=resultados;
    	
    }
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}
	public BigDecimal getNotaMaxima() {
		return notaMaxima;
	}
	public void setNotaMaxima(BigDecimal notaMaxima) {
		this.notaMaxima = notaMaxima;
	}
	public Turma getTurma() {
		return turma;
	}
	public void setTurma(Turma turma) {
		this.turma = turma;
	}
	public List<Resultado> getResultados() {
		return resultados;
	}
	public void setResultados(List<Resultado> resultados) {
		this.resultados = resultados;
	}

 
}
